package com.optimacorps.shapes.controller;

// import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optimacorps.shapes.model.AuthRequest;
import com.optimacorps.shapes.model.AuthResponse;
import com.optimacorps.shapes.model.User;
import com.optimacorps.shapes.service.UserService;

@CrossOrigin(origins="*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
	private UserService userService;

	@GetMapping("/me")
    public User welcome() {
        return userService.user();
    }

    @PostMapping("/auth/register")
    public AuthResponse addNewUser(@RequestBody User userInfo) {
		return userService.register(userInfo);
    }

	@PostMapping("/auth/login")
    public AuthResponse authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        return userService.login(authRequest);
    }

    /**
	 * Update - Update an existing user
	 * @param id - The id of the user to update
	 * @param user - The user object updated
	 * @return
	 */
	// @PutMapping("/users/{id}")
	// public User update(@PathVariable("id") final Long id, @RequestBody User shape) {
	// 	Optional<User> e = userService.show(id);
	// 	if(e.isPresent()) {
	// 		User current = e.get();

	// 		String name = shape.getName();
	// 		if(name != null) {
	// 			current.setName(name);
	// 		}

	// 		String email = shape.getEmail();
	// 		if(email != null) {
	// 			current.setEmail(email);
	// 		}

	// 		String password = shape.getPassword();
	// 		if(password != null) {
	// 			current.setPassword(password);;
	// 		}

	// 		userService.save(current);
	// 		return current;
	// 	} else {
	// 		return null;
	// 	}
	// }
}

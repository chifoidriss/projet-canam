package com.optimacorps.shapes.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optimacorps.shapes.model.Shape;
import com.optimacorps.shapes.service.ShapeService;

@CrossOrigin(origins="*", maxAge = 3600, allowedHeaders={"Accept", "Content-Type","Referer","User-Agent","x-auth-token", "x-requested-with", "x-xsrf-token", "Authorization"})
@RestController
@RequestMapping("/api")
public class ShapeController {
    @Autowired
	private ShapeService shapeService;

	/**
	 * Read - Get all shapes
	 * @return - An Iterable object of Shapes full filled
	 */
	@GetMapping("/shapes/user/{user_id}")
	public Iterable<Shape> index(@PathVariable("user_id") final Long user_id) {
		return shapeService.index(user_id);
	}

	/**
	 * Create - Add a new shape
	 * @param shape An object shape
	 * @return The shape object saved
	 */
	@PostMapping("/shapes/user/{user_id}")
	public Shape create(@PathVariable("user_id") final Long user_id, @RequestBody Shape shape) {
		return shapeService.save(user_id, shape);
	}

	/**
	 * Read - Get one shape 
	 * @param id The id of the shape
	 * @return An Shape object full filled
	 */
	@GetMapping("/shapes/{id}")
	public Shape show(@PathVariable("id") final Long id) {
		Optional<Shape> shape = shapeService.show(id);
		if(shape.isPresent()) {
			return shape.get();
		} else {
			return null;
		}
	}

	/**
	 * Update - Update an existing shape
	 * @param id - The id of the shape to update
	 * @param shape - The shape object updated
	 * @return
	 */
	@PutMapping("/shapes/{id}/{user_id}")
	public Shape update(@PathVariable("id") final Long id, @PathVariable("user_id") final Long user_id, @RequestBody Shape shape) {
		Optional<Shape> e = shapeService.show(id);
		if(e.isPresent()) {
			Shape current = e.get();

			String name = shape.getName();
			if(name != null) {
				current.setName(name);
			}
			
			String type = shape.getType();
			if(type != null) {
				current.setType(type);
			}

			Double border = shape.getBorder();
			if(border != null) {
				current.setBorder(border);
			}

			String color = shape.getColor();
			if(color != null) {
				current.setColor(color);
			}
			
            String fill = shape.getFill();
			if(fill != null) {
				current.setFill(fill);
			}
            
            Double x = shape.getX();
			if(x != null) {
				current.setX(x);
			}
            
            Double y = shape.getY();
			if(y != null) {
				current.setY(y);
			}
            
            Double r = shape.getR();
			if(r != null) {
				current.setR(r);
			}
            
            Double rx = shape.getRx();
			if(rx != null) {
				current.setRx(rx);
			}

            Double ry = shape.getRy();
			if(ry != null) {
				current.setRy(ry);
			}
            
            Double height = shape.getHeight();
			if(height != null) {
				current.setHeight(height);
			}
            
            Double width = shape.getWidth();
			if(width != null) {
				current.setWidth(width);
			}

			shapeService.save(user_id, current);
			return current;
		} else {
			return null;
		}
	}

	/**
	 * Delete - Delete an shape
	 * @param id - The id of the shape to delete
	 */
	@DeleteMapping("/shapes/{id}")
	public void delete(@PathVariable("id") final Long id) {
		shapeService.delete(id);
	}
}

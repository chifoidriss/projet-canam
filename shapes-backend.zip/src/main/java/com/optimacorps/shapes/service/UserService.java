package com.optimacorps.shapes.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.optimacorps.shapes.model.AuthRequest;
import com.optimacorps.shapes.model.AuthResponse;
import com.optimacorps.shapes.model.User;
import com.optimacorps.shapes.repository.UserRepository;

import lombok.Data;

@Data
@Service
public class UserService implements UserDetailsService {
    @Autowired
	private UserRepository userRepository;

	@Autowired
    private PasswordEncoder encoder;

	@Autowired
    private JwtService jwtService;

	@Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<User> userDetail = userRepository.findByEmail(email);

        // Converting userDetail to UserDetails
        return userDetail.map(UserInfoDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("Utilisateur inconnu " + email));
    }

    public AuthResponse register(User userInfo) {
        // userInfo.setPassword(encoder.encode(userInfo.getPassword()));
        // User saved = userRepository.save(userInfo);

		AuthResponse response = new AuthResponse();

		if (userRepository.existsByEmail(userInfo.getEmail())) {
			response.setCode(401);
			response.setMessage("Adresse email déjà utilisée");
		} else {
			userInfo.setPassword(encoder.encode(userInfo.getPassword()));
			User saved = userRepository.save(userInfo);
			response.setCode(200);
			response.setUser(saved);
			response.setToken(jwtService.generateToken(userInfo.getEmail()));
			response.setMessage("Utilisateur enregistré avec succès.");
		}

        return response;
    }
    
	public AuthResponse login(AuthRequest authRequest) {
		Optional<User> user = userRepository.findByEmail(authRequest.getEmail());
		AuthResponse response = new AuthResponse();

		if (user.isPresent()) {
			if (encoder.matches(authRequest.getPassword(), user.get().getPassword())) {
				response.setCode(200);
				response.setUser(user.get());
				response.setMessage("Utilisateur enregistré avec succès.");
				response.setToken(jwtService.generateToken(authRequest.getEmail()));
				return response;
			}
		}

		response.setCode(401);
		response.setMessage("Adresse email ou mot de passe incorrect !");
		return response;
    }

	public Optional<User> show(final Long id) {
		return userRepository.findById(id);
	}

	public Iterable<User> index() {
		return userRepository.findAll();
	}

	public void delete(final Long id) {
		userRepository.deleteById(id);
	}

	public User save(User user) {
		User saved = userRepository.save(user);
		return saved;
	}

	public String me() {
		UserDetails user = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
                    .getPrincipal();
		return user.getUsername();
	}
	
	public User user() {
		UserDetails user = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
                    .getPrincipal();
		return userRepository.findByEmail(user.getUsername()).get();
	}
}

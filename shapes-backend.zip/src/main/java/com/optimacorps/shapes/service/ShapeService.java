package com.optimacorps.shapes.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.optimacorps.shapes.model.Shape;
import com.optimacorps.shapes.model.User;
import com.optimacorps.shapes.repository.ShapeRepository;
import com.optimacorps.shapes.repository.UserRepository;

// import lombok.Data;

// @Data
@Service
public class ShapeService {
    @Autowired
	private ShapeRepository shapeRepository;

	@Autowired
	private UserRepository userRepository;

	// @Autowired
	// private UserService userService;

	public Optional<Shape> show(final Long id) {
		// Optional<User> user = userRepository.findByEmail(userService.me());
		return shapeRepository.findById(id);
	}

	public Iterable<Shape> index(final Long userId) {
		// Optional<User> user = userRepository.findByEmail(userService.me());
		Optional<User> user = userRepository.findById(userId);
		return shapeRepository.findByUser(user.get());
		// return shapeRepository.findAll();
	}

	public void delete(final Long id) {
		shapeRepository.deleteById(id);
	}

	public Shape save(final Long userId, Shape shape) {
		// Optional<User> user = userRepository.findByEmail(userService.me());
		Optional<User> user = userRepository.findById(userId);
		shape.setUser(user.get());
		return shapeRepository.save(shape);
	}
}

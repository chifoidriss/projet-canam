package com.optimacorps.shapes.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.optimacorps.shapes.model.Shape;
import com.optimacorps.shapes.model.User;

@Repository
public interface ShapeRepository extends CrudRepository<Shape, Long>{
    Iterable<Shape> findByUser(User user);
}

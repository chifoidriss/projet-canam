package com.optimacorps.shapes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShapesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShapesApplication.class, args);
	}

}

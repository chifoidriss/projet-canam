
export const APP_NAME = 'Shapes App';
export const APP_API_BASE_URL = 'http://localhost:9000/';
export const APP_API_URL = APP_API_BASE_URL+'api/';


import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  isLoad = false;
  loginView = true;
  message: string|undefined;

  loginForm: FormGroup = this.formBuilder.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required]
  });

  registerForm: FormGroup = this.formBuilder.group({
    name: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required]
  });

  constructor(private formBuilder: FormBuilder,
    public auth: AuthService) { }

  ngOnInit(): void {
  }

  login() {
    this.message = undefined;
    this.auth.login(this.loginForm.value, this);
  }

  register() {
    this.message = undefined;
    this.auth.register(this.registerForm.value, this);
  }

  changeView(val) {
    this.message = undefined;
    this.loginView = val;
  }
}

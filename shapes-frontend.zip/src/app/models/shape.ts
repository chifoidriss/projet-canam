export class Shape {
  id: number;
  name: string = 'Nouvelle forme';
  type: 'square'|'rectangle'|'ellipse'|'circle'|'diamond'|'hexagon'|string;
  fill: string = '#FFF';
  color: string = '#000';
  border: number = 1;
  height: number = 1;
  width: number = 1;
  x: number = 1;
  y: number = 1;
  r: number = 1;
  rx: number = 1;
  ry: number = 1;
}

import { Component, Input } from '@angular/core';
import { Shape } from 'src/app/models/shape';

@Component({
  selector: 'app-shape-item',
  templateUrl: './shape-item.component.html',
  styleUrls: ['./shape-item.component.scss']
})
export class ShapeItemComponent {
  @Input() item: Shape = new Shape();

  math = Math;

  ngAfterViewInit() {

  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { APP_API_URL } from 'src/env';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
	public redirectUrl: string = '/';

  constructor(private http: HttpClient,
              private router: Router) { }

  get isConnect(): boolean {
    return (this.token && this.user)?true:false;
  }

  get token(): any {
    return sessionStorage.getItem('token');
  }
  set token(value: string) {
    sessionStorage.setItem('token', value);
  }

  get user(): any {
    return localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user') || '{}') : null;
  }
  set user(value) {
    localStorage.setItem('user', JSON.stringify(value));
  }


  register(param: any, component?: any) {
    component.isLoad = true;

    this.http.post(`${APP_API_URL}auth/register`, param).subscribe({
      next: (response: any) => {
        component.isLoad = false;

        if(response.code == 200) {
          this.token = response.token;
          this.user = response.user;
          this.router.navigate([this.redirectUrl]);
          this.redirectUrl = '/';
        } else {
          component.message = response.message;
        }
      },
      error: (error) => {
        component.isLoad = false;
      }
    });
  }

  login(param: any, component?: any) {
    if (component) {
      component.isLoad = true;
    }

    this.http.post(`${APP_API_URL}auth/login`, param).subscribe({
      next: (response: any) => {
        if (component) {
          component.isLoad = false;
        }

        if(response.code == 200) {
          this.token = response.token;
          this.user = response.user;
          this.router.navigate([this.redirectUrl]);
          this.redirectUrl = '/';
        } else {
          component.message = response.message;
        }
      },
      error: (error) => {
        if (component) {
          component.isLoad = false;
        }
      }
    });
  }

  logout() {
    localStorage.clear();
    sessionStorage.clear();
    this.router.navigate(['/auth/login']);
  }
}

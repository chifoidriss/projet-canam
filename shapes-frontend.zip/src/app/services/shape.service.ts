import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { APP_API_URL } from 'src/env';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ShapeService {

  constructor(private http: HttpClient, private auth: AuthService) { }

  index(callback: any) {
    this.http.get(`${APP_API_URL}shapes/user/${this.auth.user.id}`).subscribe({
      next: (response: any) => {
        callback(response);
      },
      error: (error) => {
        // console.log(error);

        if (error.status == 403) {
          this.auth.logout();
        }
      }
    });
  }

  show(id: number, callback: any) {
    this.http.get(`${APP_API_URL}shapes/${id}`).subscribe({
      next: (response: any) => {
        callback(response);
      },
      error: (error) => {
        if (error.status == 403) {
          this.auth.logout();
        }
      }
    });
  }

  store(param: any, callback: any) {
    this.http.post(`${APP_API_URL}shapes/user/${this.auth.user.id}`, param).subscribe({
      next: (response: any) => {
        callback(response);
      },
      error: (error) => {
        if (error.status == 403) {
          this.auth.logout();
        }
      }
    });
  }

  update(id: number, param: any, callback: any) {
    this.http.put(`${APP_API_URL}shapes/${id}/${this.auth.user.id}`, param).subscribe({
      next: (response: any) => {
        callback(response);
      },
      error: (error) => {
        if (error.status == 403) {
          this.auth.logout();
        }
      }
    });
  }

  delete(id: number, callback: any) {
    this.http.delete(`${APP_API_URL}shapes/${id}`).subscribe({
      next: (response: any) => {
        callback(response);
      },
      error: (error) => {
        if (error.status == 403) {
          this.auth.logout();
        }
      }
    });
  }
}

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ShapeService } from '../services/shape.service';
import { Shape } from '../models/shape';

declare const bootstrap: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  shapes: Shape [] = [];
  shape: Shape = new Shape();
  index: number = -1;
  modal: any;

  constructor(private formBuilder: FormBuilder,
    public shapeService: ShapeService
  ) { }

  ngOnInit() {
    // ['square','rectangle','ellipse','circle','diamond','hexagon'].forEach((type, i) => {
    //   const s = new Shape();
    //   s.name = 'Nom '+i;
    //   s.type = type;
    //   s.border = 3;
    //   s.width = 100;
    //   s.height = 80;
    //   s.id = i+1;
    //   s.r = 50;
    //   s.rx = 100;
    //   s.ry = 50;
    //   this.shapes.push(s);
    // });

    this.shapeService.index((response: any []) => {
      this.shapes = response;
    });
  }

  create(type) {
    this.shape.type = type;
    this.openModal();
  }

  save() {
    this.shapeService.store(this.shape, (response) => {
      this.shapes.push(response);
      this.closeModal();
    });
  }

  edit(index: number) {
    this.shape = this.shapes[index];
    this.index = index;
    this.openModal();
  }

  update(id: number) {
    this.shapeService.update(id, this.shape, (response) => {
      this.shapes[this.index] = response;
      this.index = -1;
      this.closeModal();
    });
  }

  remove(id: number, index: number) {
    this.shapeService.delete(id, (response) => {
      this.shapes.splice(index, 1);
    });
  }

  openModal() {
    this.modal = new bootstrap.Modal(document.getElementById('addShapeModal'), {
      keyboard: false,
      backdrop: 'static'
    });
    this.modal.show();
  }

  closeModal() {
    this.modal.hide();
    this.index = -1;
    this.shape = new Shape();
  }
}
